

// export const url='http://192.168.1.60/back-end/'
// export const url='http://localhost/pup/'

// export const url='https://pup.opentech4u.co.in/pup/'
// export const url='https://pup.opentech4u.co.in/pup/'

export const auth_key='c299cf0ae55db8193eb2d3116'
export const folder_admin='uploads/'
export const folder_fund='uploads/fund/'
export const folder_tender='uploads/tender/'
export const folder_certificate='uploads/certificate/'
export const folder_progresImg='uploads/progress_image/'
