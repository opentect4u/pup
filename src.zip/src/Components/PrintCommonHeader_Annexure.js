import LOGO from "../Assets/Images/logo.png"

{/* <div class="logo">
        <img src="${LOGO}" class="mr-3 sm:h-16" alt="Logo" style="width:80px; text-align:center;"/>
      </div> */}

export const getPrintCommonHeader_Annexure = () => {
    return `
      <div class="header">
      <p>Ref Memo No.................................... Date:............................</p>
      <h3>Paschimanchal Unnayan Parshad</h3>
      <h3>Requisition of fund for following scheme STATE PLAN</h3>
    </div>
      `;
  };
  