import LOGO from "../Assets/Images/logo.png"

{/* <div class="logo">
        <img src="${LOGO}" class="mr-3 sm:h-16" alt="Logo" style="width:80px; text-align:center;"/>
      </div> */}

export const getPrintCommonHeader_PCR = () => {
    return `
      <div class="header">
      <h3>Government Of West Bengal</h3>
      <h3>Paschimanchal Unnayan Parshad</h3>
      <h3>Under the Depertment of Paschimanchal Unnayan Affairs</h3>
      <p>Ailakundi (Behind S.B.S.T.C. Garage), Kenduadihi, Bankura</p>
      <p><span class="left">Phone & Fax: 03242-243256 &nbsp &nbsp;</span>    <span class="right">e-mail:pupbankura@gmail.com/contact@pupwb.org</span></p>
    </div>
      `;
  };
  