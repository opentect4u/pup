import React from 'react'
import { Outlet } from 'react-router-dom'

function AgencyComp() {
  return (
    <div>
      <Outlet/>
      
    </div>
  )
}

export default AgencyComp
