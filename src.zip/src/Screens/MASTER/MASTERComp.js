import React from 'react'
import { Outlet } from 'react-router-dom'

function MASTERComp() {
  return (
    <div>
      <Outlet/>
      
    </div>
  )
}

export default MASTERComp
