import React from 'react'
import { Outlet } from 'react-router-dom'

function UCComp() {
  return (
    <div>
      <Outlet/>
    </div>
  )
}

export default UCComp
