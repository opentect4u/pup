import loginImg from './login_img.png'

export {
  loginImg,
}
