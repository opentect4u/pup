
export const PrintPageName= {
  Financial: 'Financial Yearwise Report',
  HeadAcc: 'Head of Accountwise Report',
  Sector:'Sector Wise Report',
  District:'District Wise Report',
  Implementing:'Implementing Agencywise Wise Report',

  popup_1:'Tender Details',
  popup_2:'Progress  Details',
  popup_3:'Fund  Details',
  popup_4:'Expenditure  Details',
  popup_5:'Utilization Certificate Details',




}