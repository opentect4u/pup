import LOGO from "../Assets/Images/logo.png"

{/* <div class="logo">
        <img src="${LOGO}" class="mr-3 sm:h-16" alt="Logo" style="width:80px; text-align:center;"/>
      </div> */}

export const getPrintCommonHeader_UC = () => {
    return `
      <div class="header">
      <h3>GFR 19-A</h3>
      <h3>(See Rule 212(1))</h3>
      <h3>Form of Utilization Certificate</h3>
    </div>
      `;
  };
  