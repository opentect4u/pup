import React from 'react'
import { Outlet } from 'react-router-dom'

function Annex_Comp() {
  return (
    <div>
      <Outlet/>
      
    </div>
  )
}

export default Annex_Comp
