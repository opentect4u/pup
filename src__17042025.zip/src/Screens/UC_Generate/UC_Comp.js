import React from 'react'
import { Outlet } from 'react-router-dom'

function UC_Comp() {
  return (
    <div>
      <Outlet/>
      
    </div>
  )
}

export default UC_Comp
