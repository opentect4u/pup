import React from 'react'
import { Outlet } from 'react-router-dom'

function AdApComp() {
  return (
    <div>
      <Outlet/>
    </div>
  )
}

export default AdApComp
