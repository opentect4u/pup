import React from 'react'
import { Outlet } from 'react-router-dom'

function USERComp() {
  return (
    <div>
      <Outlet/>
      
    </div>
  )
}

export default USERComp
